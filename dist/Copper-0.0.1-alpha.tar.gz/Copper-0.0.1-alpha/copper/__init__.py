import os
from copper.io.io import *
from copper.core.set import *
from copper.core.ml import *
from copper.core.ensemble import *

from copper.core.config import Project
project = Project()
