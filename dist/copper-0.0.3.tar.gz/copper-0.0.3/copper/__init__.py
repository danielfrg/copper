import os
from copper.core.io import *
from copper.core.set import *
from copper.core.ml import *
import copper.core.r as r

import copper.viz.base as plot

import copper.utils.transforms as transform
import copper.utils.frame
import copper.utils.ml

from copper.core.config import Project
project = Project()
