import os
from copper.io.io import *
from copper.core.set import *
from copper.core.ml import *
import copper.viz.base as plot

import copper.core.transforms as transform
import copper.core.r as r

from copper.core.config import Project
project = Project()
