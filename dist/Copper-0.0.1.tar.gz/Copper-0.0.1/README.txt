copper
======

Wrapper around pandas & scikit-learn for doing Data Analysis in python

Requirements
------------

1. Python (>=3.2)
2. pandas
3. scikit-learn
4. matplotlib

For a complete list see requirements.txt

How to use it
-------------

See the examples folder

For more information and more examples can see my blog: [danielfrg.github.com](danielfrg.github.com)
